namespace BlazorApp1.Services.OrderFiles;

public enum TicketType
{
    Physical,
    Digital
}