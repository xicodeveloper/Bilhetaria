namespace BlazorApp1.Services.OrderFiles;
public enum OrderStatus
{
    Pending,
    Completed,
    Cancelled,
}