namespace BlazorApp1.Services.Models;

public class KeywordsResponse
{
    public List<Keyword> Keywords { get; set; }
}