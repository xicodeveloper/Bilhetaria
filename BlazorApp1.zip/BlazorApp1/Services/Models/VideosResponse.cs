namespace BlazorApp1.Services.Models;

public class VideosResponse
{
    public List<Video> Results { get; set; }
}