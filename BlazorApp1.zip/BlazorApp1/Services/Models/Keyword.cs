namespace BlazorApp1.Services.Models;
public class Keyword
{
    public int Id { get; set; }
    public string Name { get; set; }
}