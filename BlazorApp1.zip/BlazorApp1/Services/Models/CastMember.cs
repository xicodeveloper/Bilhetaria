namespace BlazorApp1.Services.Models;

public class CastMember
{
    public string Name { get; set; }
}