namespace BlazorApp1.Services.Models;

public class CreditsResponse
{
    public List<CastMember> Cast { get; set; }
}